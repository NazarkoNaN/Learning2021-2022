# Prison_Management_System
This system is based on a concept to enter and manage the prisoners record  This code is made is C++

						Prison Management System In C++


Developed by Hitansh Kadakia ( https://github.com/hitanshkadakia ) and Vansh Damania ( https://github.com/vanshdamania )

Note : Login Details

	Username = admin
	Password  = pass
	
What is unique in the code !

•	Present time of the system will be displayed !!

•	Present date of the system will be displayed !!

•	Password encryption is used (if you write pass it will be printed as ****)

•	Three different types of file handling has been used (text file, html file and word file)

•	Secured management system

•	This system is easy to operate by the user.


This code will  explain us about the details of prison management system.

Once the username and password is entered 8 features will be provided

1.	New prisoner entry:  where the user can enter the details of the prisoners for example name, age, height, eyecolor, punishment duration etc.

2.	Prisoner details : where you can check all the details of the prisoners

3.	Attendance prisoner : where you can check the attendance  record of the prisoners and here you can also decrease the punishment span of the prisoners

4.	Release prisoner: where you can release the prisoner only if he/she completes the punishment duration 

5.	Search prisoner: where you can search any prisoner by its cell number

6.	Prison File: where you can download the details of the prisoners in three different file format 1) text file 2)html file 3)word file

7.	Logout: where you will logout of the system and will be directed back to the login page 

8.	Exit: where the program will be terminated and you will exit the system


The code will be more efficient at use.

Thank you
